<p>News added successfully!</p>

<br>
 <a class="btn btn-primary" href="<?php echo site_url('news') ?>"> Back to news LIst</a>
<!--<a href="#">back to Products LIst</a>-->