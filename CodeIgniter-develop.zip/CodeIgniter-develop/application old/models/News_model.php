<?php
class News_model extends CI_Model {
	//Model name as select table name 

        public function __construct()
        {
                $this->load->database();
        }
		
		
		/*   how to get news information  show model name set */
		public function get_news($slug = FALSE){
        if ($slug === FALSE)
        {
                $query = $this->db->get('news');
                return $query->result_array();
        }

        $query = $this->db->get_where('news', array('slug' => $slug));
        return $query->row_array();
}


public function get_news_id($id = FALSE){
        if ($slug === FALSE)
        {
                $query = $this->db->get('news');
                return $query->result_array();
        }

        $query = $this->db->get_where('news', array('id' => $id));
        return $query->row_array();
}
/*   set news by ID */

// its only created news

/*public function set_news(){
	
    $this->load->helper('url');
    $slug = url_title($this->input->post('title'), 'dash', TRUE);

    $data = array(
        'title' => $this->input->post('title'),
        'slug' => $slug,
        'text' => $this->input->post('text')
    );

    return $this->db->insert('news', $data);
}*/

/*  */
 public function get_news_by_id($id = 0)
    {
        if ($id === 0)
        {
            $query = $this->db->get('news');
            return $query->result_array();
        }
 
        $query = $this->db->get_where('news', array('id' => $id));
        return $query->row_array();
    }
    
    public function set_news($id = 0)
    {
        $this->load->helper('url');
 
        $slug = url_title($this->input->post('title'), 'dash', TRUE);
 
        $data = array(
            'title' => $this->input->post('title'),
            'slug' => $slug,
            'text' => $this->input->post('text')
        );
        
        if($id == 0) {
            return $this->db->insert('news', $data);
        } else {
            $this->db->where('id', $id);
            return $this->db->update('news', $data);
        }
    }
    
    public function delete_news($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('news');
    }



/*public function updata_news($data,$id) {
	
	 $this->load->helper('url');
	 $id= $this->input->post('id');

    $slug = url_title($this->input->post('title'), 'dash', TRUE);

    $data = array(
	   // 'title' => $this->input->post('title'),
        'title' => $this->input->post('title'),
        'slug' => $slug,
        'text' => $this->input->post('text')
    );

    //return $this->db->insert('news', $data);
	
    //extract($data);
    $this->db->where('id', $id);
    $this->db->update('news',$data);
    return true;
}


function show_news2() {
$id = $this->uri->segment(3);
$data['id'] = $this->News_model->show_news();
$data['news'] = $this->News_model->show_news($id);
$this->load->view('view', $data);
}

function show_news($data){
$this->db->select('*');
$this->db->from('news');
$this->db->where('id', $data);
$query = $this->db->get();
$result = $query->result();

return $result;
}


function delete_news_id($id){
$this->db->where('id', $id);
$this->db->delete('news');
}*/

}