<?php class ProductsModel extends CI_Model{
	
	
	public function __construct()
        {
                $this->load->database();
				$this->load->helper('url');
        }
	
	
        
        public function get_products(){
            if(!empty($this->input->get("search"))){
              $this->db->like('title', $this->input->get("search"));
              $this->db->or_like('description', $this->input->get("search")); 
            }
            $query = $this->db->get("products");
            return $query->result();
        }
		
		
        public function insert_product()
        {    
            $data = array(
                'title' => $this->input->post('title'),
                'description' => $this->input->post('description')
            );
            return $this->db->insert('products', $data);
        }
		
		
        public function update_product($id) 
        {
            $data=array(
                'title' => $this->input->post('title'),
                'description'=> $this->input->post('description')
            );
            if($id==0){
                return $this->db->insert('products',$data);
            }else{
                $this->db->where('id',$id);
                return $this->db->update('products',$data);
            }        
        }
		
		
		 public function set_products($id = 0){
        $this->load->helper('url');
 
        //$slug = url_title($this->input->post('title'), 'dash', TRUE);
 
        $data = array(
            'title' => $this->input->post('title'),
            //'slug' => $slug,
            'description' => $this->input->post('description')
        );
        
        if($id == 0) {
            return $this->db->insert('products', $data);
        } else {
            $this->db->where('id', $id);
            return $this->db->update('products', $data);
        }
    }
	
	
	
	public function get_products_by_id($id = 0)
    {
        if ($id === 0)
        {
            $query = $this->db->get('products');
            return $query->result_array();
        }
 
        $query = $this->db->get_where('products', array('id' => $id));
        return $query->row_array();
    }
	
	
	 public function delete_products($id){
        $this->db->where('id', $id);
        return $this->db->delete('products');
    }
    }
    ?>