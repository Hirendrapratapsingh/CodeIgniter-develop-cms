<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Products extends CI_Controller {
       /**
        * Get All Data from this method.
        *
        * @return Response
       */
	   
	   public function __construct()
        {
                parent::__construct();
                $this->load->model('ProductsModel');  
                $this->load->helper('url_helper');
        }
		
    
       public function index()
       {
		   $data['title'] = 'products archive';
           $products=new ProductsModel;
           $data['data']=$products->get_products();
           $this->load->view('templates/header',$data);       
           $this->load->view('products/list',$data);
           $this->load->view('templates/footer');
       }
       public function create()
       {
		   $data['title'] = 'create products';
          $this->load->view('templates/header',$data);
          $this->load->view('products/create');
          $this->load->view('templates/footer');      
       }
       /**
        * Store Data from this method.
        *
        * @return Response
       */
       public function store()
       {
		   $data['title'] = 'store a products item';
		   
           $products=new ProductsModel;
           $products->insert_product();
           redirect(base_url('products'));
        }
       /**
        * Edit Data from this method.
        *
        * @return Response
       */
       public function edit($id)
       {
		   $data['title'] = 'edit a products item';
           $product = $this->db->get_where('products', array('id' => $id))->row();
           $this->load->view('templates/header' ,$data);
           $this->load->view('products/edit',array('product'=>$product));
           $this->load->view('templates/footer');   
       }
       /**
        * Update Data from this method.
        *
        * @return Response
       */
       public function update($id)
       {   
	   $data['title'] = 'update a products item';
           $products=new ProductsModel;
           $products->update_product($id);
           redirect(base_url('products'));
       }
       /**
        * Delete Data from this method.
        *
        * @return Response
       */
       public function delete($id)
       {
		   $data['title'] = 'delete a products item';
           $this->db->where('id', $id);
           $this->db->delete('products');
           redirect(base_url('products'));
       }
    }
	
	?>