<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Products extends CI_Controller {
       /**
        * Get All Data from this method.
        *
        * @return Response
       */
	   
	    public function __construct()
        {
                parent::__construct();
                $this->load->model('ProductsModel');
                $this->load->helper('url_helper');
        }
		
		public function index()
{
        $data['products'] = $this->ProductsModel->get_products();
		//$data['news'] = $this->news_model->get_news();
        $data['title'] = 'Products archive';

        $this->load->view('templates/header', $data);
        $this->load->view('products/index', $data);
        $this->load->view('templates/footer');
}

	   /*public function __construct()
        {
                parent::__construct();
                $this->load->model('ProductsModel');  
                $this->load->helper('url_helper');
        }
		
    
       public function index()
       {
		   $data['title'] = 'products archive';
           $products=new ProductsModel;
           $data['data']=$products->get_products();
           $this->load->view('templates/header',$data);       
           $this->load->view('products/list',$data);
           $this->load->view('templates/footer');
       }*/
	   
	   
	    public function view($slug = NULL){
			
			$data['title'] = 'Products archive';
			$data['products_item'] = $this->ProductsModel->get_products($slug);
          // $data['news_item'] = $this->news_model->get_news($slug);

        if (empty($data['products_item']))
        {
                show_404();
        }

        $data['title'] = $data['products_item']['title'];

        $this->load->view('templates/header', $data);
        $this->load->view('products/view', $data);
        $this->load->view('templates/footer');
}



public function create()
{
    $this->load->helper('form');
    $this->load->library('form_validation');

    $data['title'] = 'create products';

    $this->form_validation->set_rules('title', 'Title', 'required', '30');
    $this->form_validation->set_rules('description', 'description', 'required');

    if ($this->form_validation->run() === FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('products/create');
        $this->load->view('templates/footer');

    }
    else
    {
        $this->ProductsModel->set_products();
        $this->load->view('products/success');
    }
}


     /*  public function create()
       {
		   $data['title'] = 'create products';
          $this->load->view('templates/header',$data);
          $this->load->view('products/create');
          $this->load->view('templates/footer');      
       }*/
       /**
        * Store Data from this method.
        *
        * @return Response
       */
	   
	    public function edit()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
        
        $this->load->helper('form');
        $this->load->library('form_validation');
        
       $data['title'] = 'edit a products item';      
       $data['products_item'] = $this->ProductsModel->get_products_by_id($id);
        
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'description', 'required');
 
        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header', $data);
            $this->load->view('products/edit', $data);
            $this->load->view('templates/footer');
 
        }
        else
        {
            $this->ProductsModel->set_products($id);
            //$this->load->view('news/success');
            redirect( base_url() . 'index.php/products/');
        }
    }
	
      /* public function store()
       {
		   $data['title'] = 'store a products item';
		   
           $products=new ProductsModel;
           $products->insert_product();
           redirect(base_url('products'));
        }*/
       /**
        * Edit Data from this method.
        *
        * @return Response
       */
       /*public function edit($id)
       {
		   $data['title'] = 'edit a products item';
           $product = $this->db->get_where('products', array('id' => $id))->row();
           $this->load->view('templates/header' ,$data);
           $this->load->view('products/edit',array('product'=>$product));
           $this->load->view('templates/footer');   
       }*/
       /**
        * Update Data from this method.
        *
        * @return Response
       */
    /*   public function update($id)
       {   
	   $data['title'] = 'update a products item';
           $products=new ProductsModel;
           $products->update_product($id);
           redirect(base_url('products'));
       }*/
       /**
        * Delete Data from this method.
        *
        * @return Response
       */
     /*  public function delete($id)
       {
		   $data['title'] = 'delete a products item';
           $this->db->where('id', $id);
           $this->db->delete('products');
           redirect(base_url('products'));
       }*/
	   
	    public function delete()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
                
        $news_item = $this->ProductsModel->get_products_by_id($id);
        
        $this->ProductsModel->delete_products($id);        
        redirect( base_url() . 'index.php/products');        
    }
    }
	
	?>