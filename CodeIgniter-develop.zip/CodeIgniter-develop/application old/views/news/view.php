
<!--<div><a href="http://127.0.0.1/CodeIgniter-develop/index.php/news/">back to news</a></div>-->
 <p><a href="<?php echo site_url('news/'); ?>">Beck Update article</a></p>

<?php
echo '<h2>'.$news_item['title'].'</h2>';
echo $news_item['text'];

?>



