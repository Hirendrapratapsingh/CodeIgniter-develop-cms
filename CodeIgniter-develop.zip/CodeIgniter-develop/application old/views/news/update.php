<h2><?php echo $title; ?></h2>

<?php echo validation_errors(); ?>

<?php echo form_open('news/edit/'.$news_item['id']); ?>


    <label for="title">Title</label>
    <input type="hidden" name="id" value="<?php echo $news_item['id'] ?>" />
 
    <input type="input" name="title" value="<?php echo $news_item['title'] ?>" /><br />
     <label for="slug">slug</label>
     <input type="input" name="slug" value="<?php echo $news_item['slug'] ?>" /><br />
    

    <label for="text">Text</label>
    <textarea name="text"><?php echo $news_item['text'] ?></textarea><br />

    <input type="submit" name="submit" value="update news item" />

</form>

