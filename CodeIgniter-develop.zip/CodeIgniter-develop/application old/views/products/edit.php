   <!--/* <form method="post" action="<?php echo base_url('products/update/'.$products_item['id']);?>">*/-->
   
   <h2><?php echo $title; ?></h2>
 
<?php echo validation_errors(); ?>
 
<?php echo form_open('products/edit/'.$products_item['id']); ?>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="form-group">
                    <label class="col-md-3">Title</label>
                    <div class="col-md-9">
                        <input type="text" name="title" class="form-control" value="<?php echo $products_item['title']; ?>">
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-md-offset-2">
                <div class="form-group">
                    <label class="col-md-3">Description</label>
                    <div class="col-md-9">
                        <textarea name="description" class="form-control"><?php echo $products_item['description']; ?></textarea>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-md-offset-2 pull-right">
                <input type="submit" name="Save" class="btn">
            </div>
        </div>
        
    </form>