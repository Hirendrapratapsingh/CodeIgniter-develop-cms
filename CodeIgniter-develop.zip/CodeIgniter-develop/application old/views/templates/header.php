<!DOCTYPE html>
    <html>
    <head>
        <title>Basic Crud operation in Codeigniter 3</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    </head>
    <body>
    <div class="container">

                <h1><?php //echo $title; ?></h1>